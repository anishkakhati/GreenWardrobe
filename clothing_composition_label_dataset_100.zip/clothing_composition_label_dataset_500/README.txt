# Clothing Composition Label Image Dataset (500 images)

This is a synthetic OCR practice dataset containing 500 individual garment composition/care label photographs.

- `images/`: 500 individual JPG label images
- `labels_metadata.csv`: ground-truth composition, country, RN/CA fields and care instructions
- Composition percentages in each record sum to 100.
- `synthetic=True`: images are generated examples, not photographs of actual retail garments.
- Washing/care pictograms are simplified illustrative symbols, not a standards-certified care-label set.

Recommended use: OCR pipeline testing, text detection, composition parsing, and data extraction prototyping.
